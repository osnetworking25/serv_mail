<?php
$CONF['configured'] = true;
$CONF['database_type'] = 'mysqli';
$CONF['database_host'] = 'localhost';
$CONF['database_port'] = '3306';
$CONF['database_user'] = 'n6S8fYTARJHJN8p4';
$CONF['database_password'] = 'W@kBn2PaEac5tTps';
$CONF['database_name'] = 'P2eahOS8O42TA5DM';
$CONF['encrypt'] = 'dovecot:ARGON2I';
$CONF['dovecotpw'] = "/usr/bin/doveadm pw -r 5";
if(@file_exists('/usr/bin/doveadm')) { // @ to silence openbase_dir stuff; see https://github.com/postfixadmin/postfixadmin/issues/171
    $CONF['dovecotpw'] = "/usr/bin/doveadm pw -r 5"; # debian
}
$CONF['setup_password'] = '$2y$10$FC1fh7UE71iOTa.yeHDYqOZSXNEQD8fFbbiwzMgPiN9J24ng4GLf.';

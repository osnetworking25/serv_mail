<html>
<head>
    <title>Postfix Admin</title>
</head>
<body>
    <p>The Postfix Admin directory layout changed.</p>
    <p>Please update your webserver config so that the DocumentRoot or Alias points to the directory "public".</p>
</body>
</html>

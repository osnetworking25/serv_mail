<?php
/* Smarty version 4.5.5, created on 2025-06-02 16:57:05
  from '/var/www/postfixadmin/templates/header.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.5',
  'unifunc' => 'content_683dd7e1369f49_80568018',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '0873562ad1aaf365dc2714902f08d9e051f6dca6' => 
    array (
      0 => '/var/www/postfixadmin/templates/header.tpl',
      1 => 1734711477,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_683dd7e1369f49_80568018 (Smarty_Internal_Template $_smarty_tpl) {
?><!doctype html>
<html lang="<?php if ((isset($_SESSION['lang']))) {
echo $_SESSION['lang'];
}?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>

    <title>Postfix Admin - <?php echo $_SERVER['HTTP_HOST'];?>
</title>
    <link rel="shortcut icon" href="<?php echo $_smarty_tpl->tpl_vars['CONF']->value['theme_favicon'];?>
"/>
    <link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['CONF']->value['theme_css'];?>
"/>
    <?php if ($_smarty_tpl->tpl_vars['CONF']->value['theme_custom_css']) {?>
        <link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['CONF']->value['theme_custom_css'];?>
"/>
    <?php }?>

    <!-- needed for datetimepicker -->
    <?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['rel_path']->value;?>
jquery-3.7.0.min.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['rel_path']->value;?>
css/bootstrap-3.4.1-dist/js/moment-with-locales.min.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['rel_path']->value;?>
css/bootstrap-3.4.1-dist/js/bootstrap.min.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['rel_path']->value;?>
css/bootstrap-3.4.1-dist/js/bootstrap-datetimepicker.min.js"><?php echo '</script'; ?>
>
</head>
<body class="lang-<?php if ((isset($_SESSION['lang']))) {
echo $_SESSION['lang'];
}?> page-<?php echo $_smarty_tpl->tpl_vars['smarty_template']->value;?>
 <?php if ((isset($_smarty_tpl->tpl_vars['table']->value))) {?>page-<?php echo $_smarty_tpl->tpl_vars['smarty_template']->value;?>
-<?php echo $_smarty_tpl->tpl_vars['table']->value;
}?>">
<?php }
}

<?php
/* Smarty version 4.5.5, created on 2025-06-04 08:17:35
  from '/var/www/postfixadmin/templates/users_main.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.5',
  'unifunc' => 'content_6840011fcd04b5_44287963',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ebdad8c2750a1ebc9134e02f839731ed7bdf778f' => 
    array (
      0 => '/var/www/postfixadmin/templates/users_main.tpl',
      1 => 1734711477,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6840011fcd04b5_44287963 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="panel panel-default" id="main_menu">
    <table class="table">
        <?php if ($_smarty_tpl->tpl_vars['CONF']->value['vacation'] === 'YES') {?>
            <tr>
                <td nowrap="nowrap"><a class="btn btn-primary" href="vacation.php"><?php echo $_smarty_tpl->tpl_vars['PALANG']->value['pUsersMenu_vacation'];?>
</a>
                </td>
                <td><?php echo $_smarty_tpl->tpl_vars['tummVacationtext']->value;?>
</td>
            </tr>
        <?php }?>
        <?php if ($_smarty_tpl->tpl_vars['CONF']->value['edit_alias'] === 'YES') {?>
            <tr>
                <td nowrap="nowrap"><a class="btn btn-primary" href="edit-alias.php"><?php echo $_smarty_tpl->tpl_vars['PALANG']->value['pUsersMenu_edit_alias'];?>
</a>
                </td>
                <td><?php echo $_smarty_tpl->tpl_vars['PALANG']->value['pUsersMain_edit_alias'];?>
</td>
            </tr>
        <?php }?>
        <tr>
            <td nowrap="nowrap"><a class="btn btn-primary" href="password.php"><?php echo $_smarty_tpl->tpl_vars['PALANG']->value['change_password'];?>
</a></td>
            <td><?php echo $_smarty_tpl->tpl_vars['PALANG']->value['pUsersMain_password'];?>
</td>
        </tr>
        <tr>
            <td nowrap="nowrap"><a class="btn btn-primary" href="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'url_user_logout');?>
"><?php echo $_smarty_tpl->tpl_vars['PALANG']->value['pMenu_logout'];?>
</a></td>
            <td><?php echo $_smarty_tpl->tpl_vars['PALANG']->value['pMain_logout'];?>
</td>
        </tr>
    </table>
</div>
<?php }
}

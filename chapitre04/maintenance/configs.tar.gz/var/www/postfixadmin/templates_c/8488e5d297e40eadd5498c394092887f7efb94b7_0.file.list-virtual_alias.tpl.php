<?php
/* Smarty version 4.5.5, created on 2025-06-03 19:05:46
  from '/var/www/postfixadmin/templates/list-virtual_alias.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.5',
  'unifunc' => 'content_683f478abf4698_55558329',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '8488e5d297e40eadd5498c394092887f7efb94b7' => 
    array (
      0 => '/var/www/postfixadmin/templates/list-virtual_alias.tpl',
      1 => 1734711477,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:list.tpl' => 1,
  ),
),false)) {
function content_683f478abf4698_55558329 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_assignInScope('table', 'alias');
$_smarty_tpl->_assignInScope('struct', $_smarty_tpl->tpl_vars['alias_data']->value['struct']);
$_smarty_tpl->_assignInScope('msg', $_smarty_tpl->tpl_vars['alias_data']->value['msg']);
$_smarty_tpl->_assignInScope('id_field', $_smarty_tpl->tpl_vars['msg']->value['id_field']);
$_smarty_tpl->_assignInScope('formconf', $_smarty_tpl->tpl_vars['alias_data']->value['formconf']);
$_smarty_tpl->_assignInScope('items', $_smarty_tpl->tpl_vars['tAlias']->value);
$_smarty_tpl->_assignInScope('RAW_items', $_smarty_tpl->tpl_vars['RAW_tAlias']->value);?>

<?php $_smarty_tpl->_subTemplateRender('file:list.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php }
}

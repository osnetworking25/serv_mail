<?php
/* Smarty version 4.5.5, created on 2025-06-04 08:20:16
  from '/var/www/postfixadmin/templates/users_edit-alias.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.5',
  'unifunc' => 'content_684001c0ac2274_71067460',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6536ac769b857421d39f06c3331dbd3ab9fbda69' => 
    array (
      0 => '/var/www/postfixadmin/templates/users_edit-alias.tpl',
      1 => 1734711477,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_684001c0ac2274_71067460 (Smarty_Internal_Template $_smarty_tpl) {
?><form name="alias" method="post" action="" class="form-horizontal">
    <div id="edit_form" class="panel panel-default">
        <div class="panel-heading"><h4><?php echo $_smarty_tpl->tpl_vars['PALANG']->value['pEdit_alias_welcome'];?>
</h4></div>
        <div class="panel-body enable-asterisk">
            <input class="flat" type="hidden" name="token" value="<?php echo rawurlencode((string)$_SESSION['PFA_token']);?>
"/>
            <p class="text-center"><em><?php echo $_smarty_tpl->tpl_vars['PALANG']->value['pEdit_alias_help'];?>
</em></p>
            <div class="form-group">
                <label class="col-md-4 col-sm-4 control-label"><?php echo $_smarty_tpl->tpl_vars['PALANG']->value['alias'];?>
:</label>
                <div class="col-md-6 col-sm-8"><p class="form-control-static"><em><?php echo $_smarty_tpl->tpl_vars['USERID_USERNAME']->value;?>
</em></p></div>
            </div>
            <div class="form-group">
                <label class="col-md-4 col-sm-4 control-label" for="fGoto"><?php echo $_smarty_tpl->tpl_vars['PALANG']->value['to'];?>
:</label>
                <div class="col-md-6 col-sm-8">
                    <textarea class="form-control" rows="8" cols="50" name="fGoto"
                              id="fGoto"><?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['tGotoArray']->value, 'field2', false, 'key2');
$_smarty_tpl->tpl_vars['field2']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['key2']->value => $_smarty_tpl->tpl_vars['field2']->value) {
$_smarty_tpl->tpl_vars['field2']->do_else = false;
echo $_smarty_tpl->tpl_vars['field2']->value;?>
&#10;<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?></textarea>
                </div>
            </div>
            <div class="form-group">
                <label class="col-md-4 col-sm-4 control-label"></label>
                <div class="col-md-6 col-sm-8">
                    <div class="radio">
                        <label>
                            <input type="radio" name="fForward_and_store" id="fForward_and_store1"
                                   value="1"<?php echo $_smarty_tpl->tpl_vars['forward_and_store']->value;?>
/>
                            <?php echo $_smarty_tpl->tpl_vars['PALANG']->value['pEdit_alias_forward_and_store'];?>

                        </label>
                    </div>
                    <div class="radio">
                        <label>
                            <input type="radio" name="fForward_and_store" id="fForward_and_store0"
                                   value="0" <?php echo $_smarty_tpl->tpl_vars['forward_only']->value;?>
/>
                            <?php echo $_smarty_tpl->tpl_vars['PALANG']->value['pEdit_alias_forward_only'];?>

                        </label>
                    </div>
                </div>
            </div>
        </div>
        <div class="panel-footer">

            <div class="btn-toolbar">
                <div class="pull-right">
                    <a href="main.php" class="mr btn btn-secondary"><?php echo $_smarty_tpl->tpl_vars['PALANG']->value['exit'];?>
</a>

                    <button class="ml btn btn-lg btn-primary" type="submit" name="submit" value="<?php echo $_smarty_tpl->tpl_vars['PALANG']->value['save'];?>
"><?php echo $_smarty_tpl->tpl_vars['PALANG']->value['save'];?>
</button>
                </div>
            </div>

        </div>
    </div>
</form>
<?php }
}

<?php
/* Smarty version 4.5.5, created on 2025-06-04 08:19:11
  from '/var/www/postfixadmin/templates/password.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.5',
  'unifunc' => 'content_6840017f75ef70_29033621',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'fed67030fc9038d35b74860002f2aa17c224c435' => 
    array (
      0 => '/var/www/postfixadmin/templates/password.tpl',
      1 => 1734711477,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6840017f75ef70_29033621 (Smarty_Internal_Template $_smarty_tpl) {
?><form name="password" method="post" action="" class="form-horizontal">
    <div id="edit_form" class="panel panel-default">
        <div class="panel-heading"><h4><?php echo $_smarty_tpl->tpl_vars['PALANG']->value['pPassword_welcome'];?>
</h4></div>
        <div class="panel-body enable-asterisk">
            <input class="flat" type="hidden" name="token" value="<?php echo rawurlencode((string)$_SESSION['PFA_token']);?>
"/>
            <div class="form-group">
                <label class="col-md-4 col-sm-4 control-label"><?php echo $_smarty_tpl->tpl_vars['PALANG']->value['pLogin_username'];?>
:</label>
                <div class="col-md-6 col-sm-8"><p class="form-control-static"><em><?php echo $_smarty_tpl->tpl_vars['SESSID_USERNAME']->value;?>
</em></p></div>
            </div>
            <div class="form-group <?php if ($_smarty_tpl->tpl_vars['pPassword_password_current_text']->value) {?>has-error<?php }?>">
                <label class="col-md-4 col-sm-4 control-label"
                       for="fPassword_current"><?php echo $_smarty_tpl->tpl_vars['PALANG']->value['pPassword_password_current'];?>
:</label>
                <div class="col-md-6 col-sm-8"><input class="form-control" type="password" name="fPassword_current"
                                                      id="fPassword_current"/></div>
                <span class="help-block"><?php echo $_smarty_tpl->tpl_vars['pPassword_password_current_text']->value;?>
</span>
            </div>
            <div class="form-group <?php if ($_smarty_tpl->tpl_vars['pPassword_password_text']->value) {?>has-error<?php }?>">
                <label class="col-md-4 col-sm-4 control-label" for="fPassword"><?php echo $_smarty_tpl->tpl_vars['PALANG']->value['pPassword_password'];?>
:</label>
                <div class="col-md-6 col-sm-8"><input class="form-control" type="password" name="fPassword"
                                                      id="fPassword" autocomplete="new-password"/></div>
                <span class="help-block"><?php echo $_smarty_tpl->tpl_vars['pPassword_password_text']->value;?>
</span>
            </div>
            <div class="form-group">
                <label class="col-md-4 col-sm-4 control-label" for="fPassword2"><?php echo $_smarty_tpl->tpl_vars['PALANG']->value['pPassword_password2'];?>
:</label>
                <div class="col-md-6 col-sm-8"><input class="form-control" type="password" name="fPassword2"
                                                      id="fPassword2" autocomplete="new-password"/></div>
            </div>
        </div>
        <div class="panel-footer">
            <div class="btn-toolbar" role="toolbar">

                <div class="pull-right">
                    <?php if ($_smarty_tpl->tpl_vars['authentication_has_role']->value['user']) {?>
                        <a href="main.php" class="btn mr btn-secondary"><?php echo $_smarty_tpl->tpl_vars['PALANG']->value['exit'];?>
</a>
                    <?php }?>

                    <button class="btn ml btn-lg btn-primary" type="submit" name="submit" value="<?php echo $_smarty_tpl->tpl_vars['PALANG']->value['change_password'];?>
"><?php echo $_smarty_tpl->tpl_vars['PALANG']->value['change_password'];?>
</button>

                </div>
            </div>
        </div>
    </div>
</form>
<?php }
}

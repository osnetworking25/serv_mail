<?php
/* Smarty version 4.5.5, created on 2025-06-04 08:17:35
  from '/var/www/postfixadmin/templates/users_menu.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.5',
  'unifunc' => 'content_6840011fcb7375_47955502',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3cfd79714a26e58750673ba780a7e0143cd0dd95' => 
    array (
      0 => '/var/www/postfixadmin/templates/users_menu.tpl',
      1 => 1734711477,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6840011fcb7375_47955502 (Smarty_Internal_Template $_smarty_tpl) {
?><nav class="navbar navbar-default navbar-fixed-top">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar"
                    aria-expanded="false" aria-controls="navbar">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
                        <a class="navbar-brand" href="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'url_user_main');?>
"><img id="login_header_logo"
                                                                                   src="../images/postbox.png"
                                                                                   alt="Logo"/></a>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
            <ul class="nav navbar-nav">
                <li><a target="_top" href="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'url_user_main');?>
"><?php echo $_smarty_tpl->tpl_vars['PALANG']->value['pMenu_main'];?>
</a></li>
                <?php if ($_smarty_tpl->tpl_vars['CONF']->value['vacation'] === 'YES') {?>
                    <li><a target="_top" href="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'url_user_vacation');?>
"><?php echo $_smarty_tpl->tpl_vars['PALANG']->value['pUsersMenu_vacation'];?>
</a></li>
                <?php }?>
                <?php if ($_smarty_tpl->tpl_vars['CONF']->value['edit_alias'] === 'YES') {?>
                    <li><a target="_top" href="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'url_user_edit_alias');?>
"><?php echo $_smarty_tpl->tpl_vars['PALANG']->value['pUsersMenu_edit_alias'];?>
</a></li>
                <?php }?>
                <li><a target="_top" href="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'url_user_password');?>
"><?php echo $_smarty_tpl->tpl_vars['PALANG']->value['change_password'];?>
</a></li>
                <li class="logout"><a target="_top" href="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'url_user_logout');?>
"><?php echo $_smarty_tpl->tpl_vars['PALANG']->value['pMenu_logout'];?>
</a></li>
            </ul>
        </div>
    </div>
</nav>
<?php }
}


Configuración
-------------

 - Edita el fichero cyrus.conf y modifica las variables $cyrus_*. El usuario debe tener permisos sobre todas las cuentas.
 - Edita los ficheros cyrus-*.pl y cambia la ruta de cyrus.conf (linea require '/path/to/cyrus.conf';)

